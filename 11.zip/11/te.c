#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#define BLOCK_SIZE   4096   


typedef struct DirectoryEntry
{
    int INode_id;                  // the id of file
    char *dirName;                 // the name of dir
    struct DirectoryEntry *next;   // the child of current directory
    struct DirectoryEntry *inDir2; // the directory in current directory
    struct DirectoryEntry *inDir;  // file in Same directory
} directory_entry;

typedef struct SuperBlock
{
    directory_entry *root;
    char *disk_name;
    int first_inode_index;
    int first_inode_idle_index;
    int first_inode_block_index;
    int blockIndex;
    int iNodeNum;
    int blockNum;
    int iNodeUsedNum;
    int blockUsedNum;

} super_block;

int main(int argc, char *argv[])
{
    struct SuperBlock sb;

	char buf[6000];

			sb.first_inode_index = 6192;
			sb.first_inode_idle_index = 6192;
			sb.first_inode_idle_index = 6192;
			sb.first_inode_block_index = 8192;
			sb.blockIndex = 8192;
			sb.iNodeNum = 256;
			sb.blockNum = 8192;
			sb.iNodeUsedNum = 0;
			sb.blockUsedNum = 0;
			memcpy(buf, &sb, 6000);

			printf("==sb=====%d=====\n", sb.blockNum);
			printf("==temp=====%s=====\n", buf);
}