  
  
  
    memcpy(buf,&sb,sizeof(sb));
     printf("\n-------------%s--------------\n", buf);
    // write(f, buf, 1024);
    // read(f, buf2,1024 );
    memcpy(&sb2,buf,1024);
    close(f);