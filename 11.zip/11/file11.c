#include "disk.h"
#include "file.h"
#include <stdlib.h>

list_directory *head;

int make_fs(char *disk_name)
{
	//fail if there is 256 files already
	if (super_block->size() == 256)
	{
		return -1;
	}
	if (make_disk(disk_name) == 0)
	{
		//craete a new INode
		iNode *file = initINode();
		//save in INode partition,size++
		super_block.add(file);
		//create a new directory entre
		directory *entry = initDirectory(file);
		//append to the directory list
		head.append(entry);
	}
	return -1;
}

int mount_fs(char *disk_name)
{
	if (open_disk(disk_name) == 0)
	{
		//bind handle
		currentHandle = handle;
		//get the information;ready to use
		LoadFile(currentHanlde);
		return 0;
	}
	return -1;
}

int umount_fs(char *disk_name)
{
	int count;
	iNode *buffer;
	//append new file
	buffer.append();
	if (close_disk(disk_name) == 0)
	{
		currentHandler = default_num;
		for (iNode in buffer)
		{
			//write back to the disk
			block_write();
		}
	}
	return -1;
}

int fs_open(char *name)
{
	directory *temp = head;
	while (temp != NULL)
	{
		if (strcmp(temp->name, name) == 0)
		{
			//find the INode Uid in the directory list
			int handle = temp->INode_id;
			for (inode in super_block)
			{
				//find the INode with the save Uid as temp and get the block index
				if (inod.Uid == temp->INode_id)
				{
					//support a maximum of 64 file descriptors that can be open simultaneously
					if (inod.Uid <= 64)
						return oinod.block_head->index;
				}
			}
		}
	}
	return -1;
}

int fs_close(int fildes)
{
	close(fildes);
	iNode *file = findFileByFildes(fildes);
	file->link_num--;
}
