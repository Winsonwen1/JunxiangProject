#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#define MAX_BUFFER 1024
#define HALF_BLOCK 8192
#include "disk.h"

typedef struct INode
{
	 // number of block
	short blockNum[8192];
	//inode creating time
	int year;
	int month;
	int day; 
	int hour; 
	int min;
	int sec;	
	int size;	 
	int offset;
} iNode;

typedef struct Block
{
  bool used[HALF_BLOCK];
} block;

typedef struct DirectoryEntry
{
  int index;
  int INode_id[256];     // the id of file
  char dirName[256][15]; // the name of dir
} directory_entry;

typedef struct Directory
{
  int index;
  int parent;            // the parent of current directory
  int dirEntry;          // file  in current directory
  int childList[256];    //  the directory in current directory
  char dirName[256][15]; // the name of dir
} list_directory;

typedef struct SuperBlock
{
  int rootDir;
  char disk_name[MAX_BUFFER];
  char pwd[MAX_BUFFER];
  int first_inode_index;
  int first_inode_idle_index;
  int first_inode_block_index;
  int blockIndex;
  int iNodeNum;
  int blockNum;
  int iNodeUsedNum;
  int blockUsedNum;
  int fileNum;
} super_block;

void nihao();

int main(int argc, char *argv[])
{
  nihao();

  time_t rawtime;
  int year, month, day, hour, min, sec;
  struct tm *timeinfo;
  time(&rawtime);
  timeinfo = localtime(&rawtime);
  year = 1900 + timeinfo->tm_year;
  month = 1 + timeinfo->tm_mon;
  day = timeinfo->tm_mday;
  hour = timeinfo->tm_hour;
  min = timeinfo->tm_min;
  sec = timeinfo->tm_sec;
  printf("当前时间:%4d-%02d-%02d %02d:%02d:%02d\n\n", year, month, day, hour, min, sec);
  printf("你需要的格式:%4d%02d%02d%02d%02d%02d\n\n", year, month, day, hour, min, sec);
}

void nihao()
{

  make_disk("aaaa");

  char *disk_name = "aaaa";
  struct SuperBlock sb;

  open_disk(disk_name);

  sb.first_inode_index = 6192;
  sb.first_inode_idle_index = 6192;
  sb.first_inode_idle_index = 6192;
  sb.first_inode_block_index = 8192;
  sb.blockIndex = 8192;
  sb.iNodeNum = 256;
  sb.blockNum = 8192;
  sb.iNodeUsedNum = 0;

  sb.blockUsedNum = 0;

  char buf[BLOCK_SIZE];
  memcpy(buf, &sb, BLOCK_SIZE);
  block_write(0, buf);
  // printf("==iiii=====%d=====\n", i);
  // printf("==sb=====%d=====\n", sb.blockNum);
  // printf("==temp=====%s=====\n", buf);
  // block_read(0, temp2);
  // memcpy(&sb2, temp2, MAX_BUFFER);
  printf("==sb=====%d=====\n", sb.first_inode_idle_index);
  printf("==temp=====%s=====\n", buf);
  // close_disk(disk_name);

  char buf2[BLOCK_SIZE];
  struct SuperBlock sb2;
  // open_disk(disk_name);
  block_read(0, buf2);
  memcpy(&sb2, buf2, BLOCK_SIZE);
  close_disk(disk_name);
  printf("===========%ld============\n", sizeof(struct DirectoryEntry));
  printf("===========%ld============\n", sizeof(struct INode));
  //   printf("===========%d============\n", sb.blockNum);
  // printf("\n===========%d============\n", sb2.blockNum);

  //   printf("\n-------------%s--------------\n", buf2);
  // printf("===========%ld============\n", sizeof(struct SuperBlock));
  // //   printf("===========%d============\n", sb.blockNum);
  //   printf("===========%d============", sb2.blockNum);
  //   printf("===========%d============", sb2.blockUsedNum);
}

/******************************************************************************/

// int main(int argc, char *argv[])
// {

//     char* buf;
//     char buf2[MAX_BUFFER];

//     struct SuperBlock sb ;
//     struct SuperBlock sb2 ;
//     sb.blockNum = 1844;
//     sb.disk_name = "5566";
//     sb.blockUsedNum = 897987;
//     	sb.first_inode_index = 6192;
// 			sb.first_inode_idle_index = 6192;
// 			sb.first_inode_idle_index = 6192;
// 			sb.first_inode_block_index = 8192;
// 			sb.blockIndex = 8192;
// 			sb.iNodeNum = 256;
// 			sb.blockNum = 8192;
// 			sb.iNodeUsedNum = 0;
// 			sb.blockUsedNum = 5789;

//     int f;
//     memcpy(buf2, &sb, MAX_BUFFER);

//      f = open("ni.txt", O_RDWR, 0644);
//     write(f, buf, MAX_BUFFER);
//     close(f);
//  printf("\n-------------%s--------------\n", buf);

//     // f = open("ni.txt", O_RDWR, 0644);
//     // read(f, buf2, MAX_BUFFER);
//     // memcpy(&sb2, buf2, MAX_BUFFER);
//     // close(f);

//     // printf("\n-------------%s--------------\n", buf2);
//     // // printf("===========%ld============\n", sizeof(sb));
//     // // printf("===========%d============\n", sb->blockNum);
//     // printf("===========%d============", sb2.blockNum);
//     // printf("===========%d============", sb2.blockUsedNum);
// }

/******************************************************************************/
static int active = 0; /* is the virtual disk open (active) */
static int handle;     /* file handle to virtual disk       */

/******************************************************************************/

int make_disk(char *name)
{
  int f, cnt;
  char buf[BLOCK_SIZE];
  char buf2[BLOCK_SIZE];
  if (!name)
  {
    fprintf(stderr, "make_disk: invalid file name\n");
    return -1;
  }

  if ((f = open(name, O_WRONLY | O_CREAT | O_TRUNC, 0644)) < 0)
  {
    perror("make_disk: cannot open file");
    return -1;
  }

  memset(buf, 0, BLOCK_SIZE);
  memset(buf2, 1, BLOCK_SIZE);
  for (cnt = 0; cnt < DISK_BLOCKS; ++cnt)
  {
    if (cnt >= 5)
    {
      write(f, buf2, BLOCK_SIZE);
    }
    else
    {
      write(f, buf, BLOCK_SIZE);
    }
  }

  close(f);

  return 0;
}

int open_disk(char *name)
{
  int f;

  if (!name)
  {
    fprintf(stderr, "open_disk: invalid file name\n");
    return -1;
  }

  if (active)
  {
    fprintf(stderr, "open_disk: disk is already open\n");
    return -1;
  }

  if ((f = open(name, O_RDWR, 0644)) < 0)
  {
    perror("open_disk: cannot open file");
    return -1;
  }

  handle = f;
  active = 1;

  return 0;
}

int close_disk()
{
  if (!active)
  {
    fprintf(stderr, "close_disk: no open disk\n");
    return -1;
  }

  close(handle);

  active = handle = 0;

  return 0;
}

int block_write(int block, char *buf)
{
  if (!active)
  {
    fprintf(stderr, "block_write: disk not active\n");
    return -1;
  }

  if ((block < 0) || (block >= DISK_BLOCKS))
  {
    fprintf(stderr, "block_write: block index out of bounds\n");
    return -1;
  }

  if (lseek(handle, block * BLOCK_SIZE, SEEK_SET) < 0)
  {
    perror("block_write: failed to lseek");
    return -1;
  }

  if (write(handle, buf, BLOCK_SIZE) < 0)
  {
    perror("block_write: failed to write");
    return -1;
  }

  return 0;
}

int block_read(int block, char *buf)
{
  if (!active)
  {
    fprintf(stderr, "block_read: disk not active\n");
    return -1;
  }

  if ((block < 0) || (block >= DISK_BLOCKS))
  {
    fprintf(stderr, "block_read: block index out of bounds\n");
    return -1;
  }

  if (lseek(handle, block * BLOCK_SIZE, SEEK_SET) < 0)
  {
    perror("block_read: failed to lseek");
    return -1;
  }

  if (read(handle, buf, BLOCK_SIZE) < 0)
  {
    perror("block_read: failed to read");
    return -1;
  }

  return 0;
}
