#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdbool.h>

#define MAX_BUFFER 1024 // The max length of a command in one line is 1024 char
#define MAX_ARGS 64		// The max length of a command in one line is 64 commands
#define HALF_BLOCK 8192
#define MAX_FILES 256
#define DIR_SIZE 66316
#define DOUBLE_BLOCK_SIZE 8129
#define ENTRY_SIZE 66308
#define DIRECTORY_BEGIN_INDEX 5
#define DIRECTORY_END_INDEX 3455
#define DIRECTORY_ENTRY_BEGIN_INDEX 3456
#define DIRECTORY_ENTRY_END_INDEX 6889
#define INODE_BEGIN_INDEX 6912
#define INODE_END_INDEX 8191

static char *diskName;
static int isMout;     /* file handle to virtual disk       */
static int isOpen;


 
typedef struct INode
{
	int size; // number of block
	short blockNum[8192];
	int ctime; //inode creating time
			   // char owner[MAX_BUFFER]; //owner of this file
} iNode;

typedef struct Block
{
	bool used[HALF_BLOCK];
} block;

typedef struct DirectoryEntry
{
	int index;
	int INode_id[256];		// the id of file
	char dirName[255][256]; // the name of dir
} directory_entry;

typedef struct Directory
{
	int index;
	int parent;				// the parent of current directory
	int dirEntry;			// file  in current directory
	int childList[256];   //  the directory in current directory
	char dirName[255][256]; // the name of dir
} list_directory;

typedef struct SuperBlock
{
	int rootDir;
	char disk_name[MAX_BUFFER];
	char pwd[MAX_BUFFER];
	int first_inode_index;
	int first_inode_idle_index;
	int first_inode_block_index;
	int blockIndex;
	int iNodeNum;
	int blockNum;
	int iNodeUsedNum;
	int blockUsedNum;
	int fileNum;
} super_block;

int initBlock();
int runOneCommand(char *command[]);
int initSuperBlock(struct SuperBlock sb);
void splitInput(char *command[], char inputD[]);
int initlistD(int parentIndex);
int mount_fs(char *disk_name);
int  umount_fs(char* disk_name);
int wirteBacklistD();
int wirteBackBlock();
int wirteBackSuperBlock();
int wirteDirEntry();
int initEntry(int index);
