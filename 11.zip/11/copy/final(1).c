
#include "final4.h"
#include "disk.h"

iNode inode[64]; // the max number to open files
int fd[65];
char pwd[1024];
struct Block nodeBlock;
struct Block dataBlock;
struct Directory rootDirList;
struct Directory currectDirList;
struct DirectoryEntry currectEntry;
struct SuperBlock superBlock;

// struct Directory dir;
int main()
{
	fprintf(stderr, "%d", currectEntry.index);
	char inputD[1024] = {}; // input data from user
	char *command[1024] = {};
	isMout = 0;
	isOpen = 0;
	// int r; //store return value
	while (1)
	{
		//	display the instruction
		//	line = get line from user;
		//	commands <- split line by ' ';
		//	runOneCommand(command);

		fprintf(stderr, "%s", "Please type your command: ");
		fgets(inputD, sizeof(char) * MAX_BUFFER, stdin);
		//			for(int i; command[i]!=NULL; i++) {
		//		printf("%s\n",command[i]);
		//	}
		splitInput(command, inputD);

		runOneCommand(command);
	}
}

int umount_fs(char *disk_name)
{
	//o write back all meta-information so that the disk persistently reflects
	//all changes that were made to the file system
	//close the disk. The function returns 0 on success, and -1 when the
	//disk disk_name could not be closed or when data could not be written to the disk

	if (isMout != 1)
	{
		fprintf(stderr, "File system is not mounted yet!! \n");
		return -1;
	}

	if (strcmp(disk_name, diskName) != 0)
	{
		fprintf(stderr, "File system is not mounted yet!! \n");
		return -1;
	}

	if (wirteBacklistD(DIRECTORY_BEGIN_INDEX) == 0)
	{

		if (wirteBackBlock() == 0)
		{

			if (wirteBackSuperBlock() == 0)
			{
				if (wirteDirEntry() == 0)
				{
					if (close_disk(disk_name) == 0)
					{
						isOpen = 0;
						strcpy(pwd, "");
						diskName = NULL;
						isMout = 0;
						fprintf(stderr, "umounted file system successful\n");
						return 0;
					}

					return -1;
				}
				fprintf(stderr, "Storing Dir Entry failed\n");
				return -1;
			}
			fprintf(stderr, "Storing super block failed\n");
			return -1;
		}
		fprintf(stderr, "Storing nodeBlockk or dataBlock failed\n");
		return -1;
	}

	close_disk(disk_name);
	isOpen = 0;
	return -1;
}

int wirteDirEntry()
{
	int index1 = currectEntry.index;
	if (index1 == 0)
	{
		return 0;
	}

	int j;
	char buf[ENTRY_SIZE];
	char temp[BLOCK_SIZE];
	memcpy(buf, &rootDirList, ENTRY_SIZE);

	for (int k = 0; k < 17; k++)
	{
		strncpy(temp, buf + BLOCK_SIZE * k, BLOCK_SIZE);

		j = block_write(index1 + k, temp);
		if (j != 0)
		{
			return -1;
		}
	}
	memset(&currectEntry, 0, sizeof(struct DirectoryEntry));

	return 0;
}

int wirteBacklistD()
{

	int index1 = 5;
	int j;
	char buf[DIR_SIZE];
	char temp[BLOCK_SIZE];
	memcpy(buf, &rootDirList, DIR_SIZE);

	for (int k = 0; k < 17; k++)
	{
		strncpy(temp, buf + BLOCK_SIZE * k, BLOCK_SIZE);

		j = block_write(index1 + k, temp);
		if (j != 0)
		{
			fprintf(stderr, "Directory initial failed\n");
			return -1;
		}
	}

	if (currectDirList.index == DIRECTORY_BEGIN_INDEX)
	{

		memset(&rootDirList, 0, sizeof(struct Directory));

		memset(&currectDirList, 0, sizeof(struct Directory));
		return 0;
	}

	memcpy(buf, &currectDirList, DIR_SIZE);

	for (int k = 0; k < 17; k++)
	{
		strncpy(temp, buf + BLOCK_SIZE * k, BLOCK_SIZE);

		j = block_write(index1 + k, temp);

		if (j != 0)
		{
			fprintf(stderr, "Storing Directory failed\n");
			return -1;
		}
	}

	memset(&rootDirList, 0, sizeof(struct Directory));

	memset(&currectDirList, 0, sizeof(struct Directory));

	if (j == 0)
	{
		return 0;
	}

	return -1;
}

int wirteBackBlock()
{
	char buf[DOUBLE_BLOCK_SIZE];
	char temp[BLOCK_SIZE];

	memcpy(buf, &nodeBlock, DOUBLE_BLOCK_SIZE);

	for (int i = 1; i < 3; i++)
	{
		if (i == 1)
		{
			strncpy(temp, buf, BLOCK_SIZE);
			block_write(i, buf);
		}
		else if (i == 2)
		{
			strncpy(temp, buf + BLOCK_SIZE, BLOCK_SIZE);
			block_write(i, temp);
		}
	}

	memcpy(buf, &dataBlock, DOUBLE_BLOCK_SIZE);

	for (int i = 3; i < 5; i++)
	{
		if (i == 3)
		{
			strncpy(temp, buf, BLOCK_SIZE);
			block_write(i, buf);
		}
		else if (i == 4)
		{
			strncpy(temp, buf + BLOCK_SIZE, BLOCK_SIZE);
			block_write(i, temp);

			memset(&nodeBlock, 0, sizeof(struct Block));
			memset(&dataBlock, 0, sizeof(struct Block));
			return 0;
		}
	}

	return -1;
}

int wirteBackSuperBlock()
{

	char buf[BLOCK_SIZE];
	memcpy(buf, &superBlock, BLOCK_SIZE);
	int i = block_write(0, buf);
	if (i == 0)
	{
		memset(&superBlock, 0, sizeof(struct SuperBlock));
		return 0;
	}

	return -1;
}

int mount_fs(char *disk_name)
{
	//open the disk and then load the meta-information
	// that is necessary to handle the file system operations
	// The function returns 0 on success, and -1 when the disk disk_name could not
	//be opened or when the disk does not contain a valid file system
	char buf2[BLOCK_SIZE];
	char blockBuf[DOUBLE_BLOCK_SIZE];

	if (open_disk(disk_name) == -1)
	{

		return -1;
	}
	isOpen = 1;
	//initial super block
	block_read(0, buf2);
	memcpy(&superBlock, buf2, BLOCK_SIZE);
	printf("==========%d\n", 444);
	if (superBlock.blockNum == 0)
	{
		fprintf(stderr, "%s\n", "File System is not initail yet, Ple make a File System for this disk first ");
		close_disk(disk_name);
		isOpen = 0;
		return -1;
	}

	printf("==========%d\n", 333);
	// initial nodeBlock and data Block
	for (int i = 1; i < 5; i++)
	{
		if (i == 1)
		{
			block_read(i, buf2);
			strcpy(blockBuf, buf2);
		}
		else if (i == 2)
		{
			block_read(i, buf2);
			strcat(blockBuf, buf2);
			memcpy(&nodeBlock, buf2, DOUBLE_BLOCK_SIZE);
		}
		else if (i == 3)
		{
			block_read(i, buf2);
			strcpy(blockBuf, buf2);
		}
		else if (i == 4)
		{
			block_read(i, buf2);
			strcat(blockBuf, buf2);
			memcpy(&dataBlock, buf2, DOUBLE_BLOCK_SIZE);
		}
	}
	//initial rootDirlist
	char dirBuf[DIR_SIZE];

	for (int k = 5; k < 22; k++)
	{
		if (k == 5)
		{
			block_read(k, buf2);
			strncpy(dirBuf, buf2, BLOCK_SIZE);
			continue;
		}
		// if(k==21){
		// 	block_read(k, buf2);
		// 	strncat(dirBuf, buf2, 3828);
		// 	break;
		// }

		block_read(k, buf2);
		strncat(dirBuf, buf2, BLOCK_SIZE);
	}
	printf("==========%d\n", 222);
	memcpy(&rootDirList, dirBuf, DIR_SIZE);
	printf("==========%d\n", rootDirList.index);
	memcpy(&currectDirList, dirBuf, DIR_SIZE);
	printf("==========%d\n", currectDirList.index);

	// superBlock.root = rootDirList;

	// printf("666\n");
	// testing
	// fprintf(stderr, "index%d\n", superBlock.rootDir);
	// fprintf(stderr, "index2===%d\n", rootDirList.index);
	// fprintf(stderr, "index2===%d\n", currectDirList.index);
	// fprintf(stderr, "index2===%d\n", dataBlock.used[1]);
	// fprintf(stderr, "index2===%d\n", nodeBlock.used[1]);
	// close_disk(disk_name);
	// update pwd

	for (int j = 0; disk_name[j] != '\0'; j++)
	{

		pwd[j] = disk_name[j];
	}
	// strcpy(pwd, diskName);

	strcat(pwd, ":/root/");

	fprintf(stderr, "%s\n", "Mounted Disk successful!");
	isMout = 1;

	diskName = disk_name;
	return 0;
}

int make_fs(char *disk_name)
{
	// first invoke make_disk(disk_name) to create a new disk
	//  open this disk and write/initialize the necessary meta-information
	// for file system
	// The function returns 0 on success, and -1 when the disk
	// disk_name could not be created, opened, or properly initialized.

	char inputD[1024] = {};
	char buf2[BLOCK_SIZE];
	struct SuperBlock sb2;

	if (isOpen == 1)
	{
		fprintf(stderr, "%s\n", "Please closed disk first ");
		return -1;
	}
	if (open_disk(disk_name) == -1)
	{
		return -1;
	}

	block_read(0, buf2);
	memcpy(&sb2, buf2, BLOCK_SIZE);
	close_disk(disk_name);
	isOpen = 0;
	// printf("-----------%d--------", sb2.blockNum);

	if (sb2.blockNum != 0)
	{
		fprintf(stderr, "%s\n", "File System is initail already, Type '1' if u wanna continue ");
		fgets(inputD, sizeof(char) * MAX_BUFFER, stdin);
		if (inputD[0] != '1')
		{
			fprintf(stderr, "%s\n", "Back to the main menu ");
			return 0;
		}
	}

	if (make_disk(disk_name) == 0)
	{
		if (open_disk(disk_name) == 0)
		{
			isOpen = 1;
			diskName = disk_name;
			if (initlistD(0) == 0)
			{
				if (initBlock() == 0)
				{
					if (initSuperBlock(sb2) == 0)
					{
						if (close_disk(disk_name) == 0)
						{
							isOpen = 0;
							diskName = NULL;
							return 0;
						}

						return -1;
					}
					fprintf(stderr, "initial super block failed\n");
					return -1;
				}
				fprintf(stderr, "initial nodeBlockk or dataBlock failed\n");
				return -1;
			}
			fprintf(stderr, "initial rootDirList failed\n");
			return -1;
		}
		fprintf(stderr, "initial superblock failed\n");
	}

	return -1;
}

int initSuperBlock(struct SuperBlock sb)
{

	sb.rootDir = 5;
	sb.first_inode_index = 6192;
	sb.first_inode_idle_index = 6192;
	sb.first_inode_idle_index = 6192;
	sb.first_inode_block_index = 8192;
	sb.blockIndex = 8192;
	sb.iNodeNum = 256;
	sb.blockNum = 8192;
	sb.iNodeUsedNum = 0;
	sb.fileNum = 1;
	strcpy(sb.disk_name, diskName);
	sb.blockUsedNum = 0;
	// printf("------%s-----", sb.disk_name);
	char buf[BLOCK_SIZE];
	memcpy(buf, &sb, BLOCK_SIZE);
	int i = block_write(0, buf);

	if (i == 0)
	{
		fprintf(stderr, "initial successful\n");
		return 0;
	}

	return -1;
}

int initBlock()
{
	block nb;
	char buf[DOUBLE_BLOCK_SIZE];
	char temp[BLOCK_SIZE];
	nb.used[0] = true;
	nb.used[1] = true;

	memcpy(buf, &nb, DOUBLE_BLOCK_SIZE);

	for (int i = 1; i < 3; i++)
	{
		if (i == 1)
		{
			strncpy(temp, buf, BLOCK_SIZE);
			block_write(i, buf);
		}
		else if (i == 2)
		{
			strncpy(temp, buf + BLOCK_SIZE, BLOCK_SIZE);
			block_write(i, temp);
			return 0;
		}
	}
	return -1;
}

int initEntry(int index)
{

	struct DirectoryEntry dirEntry;

	if (index == DIRECTORY_ENTRY_BEGIN_INDEX)
	{
		dirEntry.index = index;
	}
	else
	{
		// 当不是根目录
	}

	int j;
	char buf[ENTRY_SIZE];
	char temp[BLOCK_SIZE];
	memcpy(buf, &dirEntry, ENTRY_SIZE);

	for (int k = 0; k < 17; k++)
	{
		strncpy(temp, buf + BLOCK_SIZE * k, BLOCK_SIZE);

		j = block_write(dirEntry.index + k, temp);
		if (j != 0)
		{
			fprintf(stderr, "Directory initial failed\n");
			return -1;
		}
	}
	// fprintf(stderr, "rootindex2===%d\n", dir->index);
	if (j == 0)
	{
		return 0;
	}

	return -1;
}

int initlistD(int parentIndex)
{

	struct Directory dir;

	if (nodeBlock.used[0] == false)
	{
		dir.dirEntry = initEntry(DIRECTORY_ENTRY_BEGIN_INDEX);
	}
	else
	{
		// 当不是根目录
	}

	if (parentIndex == 0)
	{
		dir.index = 5;
	}
	else
	{
		// 当不是根目录
	}

	dir.parent = parentIndex;

	int j;
	char buf[DIR_SIZE];
	char temp[BLOCK_SIZE];
	memcpy(buf, &dir, DIR_SIZE);

	for (int k = 0; k < 17; k++)
	{
		strncpy(temp, buf + BLOCK_SIZE * k, BLOCK_SIZE);

		j = block_write(dir.index + k, temp);
		if (j != 0)
		{
			fprintf(stderr, "Directory initial failed\n");
			return -1;
		}
	}
	// fprintf(stderr, "rootindex2===%d\n", dir->index);
	if (j == 0)
	{
		return 0;
	}

	return -1;
}

/*  Function "runOneCommand"  :  used to Run a command */
int runOneCommand(char *command[])
{
	//check command
	int r;

	if (strcmp(command[0], "mkDisk") == 0)
	{

		r = make_disk(command[1]);
		if (r == 0)
		{
		}
		return 1;
	}
	else if (strcmp(command[0], "oDisk") == 0)
	{
		r = open_disk(command[1]);

		if (r == 0)
		{
			isOpen = 1;
			fprintf(stderr, "open disk successful \n");
			diskName = command[1];
		}

		return 2;
	}
	else if (strcmp(command[0], "cDisk") == 0)
	{
		r = close_disk(command[1]);

		if (r == 0)
		{
			isOpen = 0;
			diskName = NULL;
			fprintf(stderr, "close disk successful \n");
		}

		return 3;
	}
	else if (strcmp(command[0], "mkFS") == 0)
	{
		make_fs(command[1]);
		return 4;
	}
	else if (strcmp(command[0], "mouFS") == 0)
	{
		mount_fs(command[1]);

		return 5;
	}
	else if (strcmp(command[0], "umouFS") == 0)
	{
		umount_fs(command[1]);
		return 6;
	}
	else if (strcmp(command[0], "help") == 0)
	{
		return 7;
	}
	else if (strcmp(command[0], "pause") == 0)
	{
		// return;
	}
	else if (strcmp(command[0], "quit") == 0)
	{
		return -1;
	}
	else
	{
		fprintf(stderr, "%s\n", "Can't find this command!! Retry!'");
		return 0;
	}
	return -1;
}

/*  Function "splitInput"  : split input for execute */
void splitInput(char *command[], char inputD[])
{

	char temp[1024][300];
	int i = 0; // the index of iputD
	int j = 0;
	int c = 0;	 // the index for temp
	int index = 0; // index for commands
	int bool1 = 1; //when input if not end
	int tick = 0;  // if not first 'space' or enter

	if (inputD[0] == '\0' || inputD[0] == 10)
	{

		return;
	}

	while (bool1)
	{
		while (inputD[i] == 10 || inputD[i] == ' ' || inputD[i] == '\t' || inputD[i] == '\0')
		{
			if (tick == 0)
			{
				i++;
				continue;
			}
			if (j == 0)
			{
				temp[index][c] = '\0';
				command[index] = temp[index];
				index += 1;
				c = 0;
				j++;
			}

			if (inputD[i] == '\0')
			{
				bool1 = 0;
				break;
			}
			i++;
		}

		temp[index][c] = inputD[i];

		tick = 1;
		c++;
		j = 0;
		i++;
	}

	command[index] = NULL;

} // end Function "splitInput"
