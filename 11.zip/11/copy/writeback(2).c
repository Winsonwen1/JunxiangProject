#include "final4.h"
#include "disk.h"


int wirteDirEntry()
{
	int index1 = currectEntry.index;
	if (index1 == 0)
	{
		return 0;
	}

	int j;
	char buf[ENTRY_SIZE];
	char temp[BLOCK_SIZE];
	memcpy(buf, &currectEntry, ENTRY_SIZE);

	for (int k = 0; k < 2; k++)
	{
		strncpy(temp, buf + BLOCK_SIZE * k, BLOCK_SIZE);

		j = block_write(index1 + k, temp);
		if (j != 0)
		{
			return -1;
		}
	}
	memset(&currectEntry, 0, sizeof(struct DirectoryEntry));

	return 0;
}

int wirteBacklistD()
{

	int index1 = currectDirList.index;
	int j;
	char buf[DIR_SIZE];
	char temp[BLOCK_SIZE];

	memcpy(buf, &currectDirList, DIR_SIZE);

	for (int k = 0; k < 2; k++)
	{
		strncpy(temp, buf + BLOCK_SIZE * k, BLOCK_SIZE);

		j = block_write(index1 + k, temp);

		if (j != 0)
		{
			fprintf(stderr, "Storing Directory failed\n");
			return -1;
		}
	}



	memset(&currectDirList, 0, sizeof(struct Directory));

	if (j == 0)
	{
		return 0;
	}

	return -1;
}

int wirteBackBlock()
{
	char buf[DOUBLE_BLOCK_SIZE];
	char temp[BLOCK_SIZE];

	memcpy(buf, &nodeBlock, DOUBLE_BLOCK_SIZE);

	for (int i = 1; i < 3; i++)
	{
		if (i == 1)
		{
			strncpy(temp, buf, BLOCK_SIZE);
			block_write(i, buf);
		}
		else if (i == 2)
		{
			strncpy(temp, buf + BLOCK_SIZE, BLOCK_SIZE);
			block_write(i, temp);
		}
	}

	memcpy(buf, &dataBlock, DOUBLE_BLOCK_SIZE);

	for (int i = 3; i < 5; i++)
	{
		if (i == 3)
		{
			strncpy(temp, buf, BLOCK_SIZE);
			block_write(i, buf);
		}
		else if (i == 4)
		{
			strncpy(temp, buf + BLOCK_SIZE, BLOCK_SIZE);
			block_write(i, temp);

			memset(&nodeBlock, 0, sizeof(struct Block));
			memset(&dataBlock, 0, sizeof(struct Block));
			return 0;
		}
	}

	return -1;
}

int wirteBackSuperBlock()
{

	char buf[BLOCK_SIZE];
	memcpy(buf, &superBlock, BLOCK_SIZE);
	int i = block_write(0, buf);
	if (i == 0)
	{
		memset(&superBlock, 0, sizeof(struct SuperBlock));
		return 0;
	}

	return -1;
}