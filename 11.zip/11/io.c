
#include "final4.h"
#include "disk.h"

struct SuperBlock superBlock;
// iNode inode[256]; // the max number of files
int fd[64];
char pwd[1024];
block nodeBlock;
block dataBlock;
struct Directory rootDirList;
struct Directory currectDirList;
struct DirectoryEntry currectEntry;

int main()
{
	char inputD[1024] = {}; // input data from user
	char *command[1024] = {};
	strcpy(pwd, "root");
	// int r; //store return value
	while (1)
	{
		//	display the instruction
		//	line = get line from user;
		//	commands <- split line by ' ';
		//	runOneCommand(command);

		fprintf(stderr, "%s", "Please type your command: ");
		fgets(inputD, sizeof(char) * MAX_BUFFER, stdin);
		//			for(int i; command[i]!=NULL; i++) {
		//		printf("%s\n",command[i]);
		//	}
		splitInput(command, inputD);

		runOneCommand(command);
	}
}

int make_fs(char *disk_name)
{
	// first invoke make_disk(disk_name) to create a new disk
	//  open this disk and write/initialize the necessary meta-information
	// for file system
	// The function returns 0 on success, and -1 when the disk
	// disk_name could not be created, opened, or properly initialized.
	struct SuperBlock sb;

	char inputD[1024] = {};
	char buf2[BLOCK_SIZE];
	struct SuperBlock sb2;

	if (open_disk(disk_name) == -1)
	{
		return -1;
	}

	block_read(0, buf2);
	memcpy(&sb2, buf2, BLOCK_SIZE);
	close_disk(disk_name);

	if (sb2.blockNum != 0)
	{
		fprintf(stderr, "%s\n", "File System is initail already, Type '1' if u wanna continue ");
		fgets(inputD, sizeof(char) * MAX_BUFFER, stdin);
		if (inputD[0] != '1')
		{
			fprintf(stderr, "%s\n", "Back to the main menu ");
			return 0;
		}
	}

	if (make_disk(disk_name) == 0)
	{
		if (open_disk(disk_name) == 0)
		{
			diskName = disk_name;
			if (initSuperBlock(sb) == 0)
			{
				if (close_disk(disk_name) == 0)
				{
					diskName = NULL;
					return 0;
				}

				return -1;
			}
			fprintf(stderr, "initial superblock failed\n");
			return -1;
		}
	}

	return -1;
}

int mount_fs(char *disk_name)
{
	//open the disk and then load the meta-information
	// that is necessary to handle the file system operations
	// The function returns 0 on success, and -1 when the disk disk_name could not
	//be opened or when the disk does not contain a valid file system
	printf("111\n");
	char buf2[BLOCK_SIZE];
	// struct SuperBlock sb2;
	char blockBuf[HALF_BLOCK];
	if (open_disk(disk_name) == -1)
	{
		return -1;
	}
	block_read(0, buf2);
	memcpy(&superBlock, buf2, BLOCK_SIZE);
	printf("111\n");
	if (superBlock.blockNum == 0)
	{
		fprintf(stderr, "%s\n", "File System is not initail yet, Ple make a File System for this disk first ");
		close_disk(disk_name);
		return -1;
	}
	printf("222\n");

	// fprintf(stderr, "diskneame ======%s\n", superBlock.disk_name);
	printf("333\n");
	for (int i = 1; i < 5; i++)
	{
		if (i == 1)
		{
			block_read(i, buf2);
			strcpy(blockBuf, buf2);
		}
		else if (i == 2)
		{
			block_read(i, buf2);
			strcat(blockBuf, buf2);
			memcpy(&nodeBlock, buf2, HALF_BLOCK);
		}
		else if (i == 3)
		{
			block_read(i, buf2);
			strcpy(blockBuf, buf2);
		}
		else if (i == 4)
		{
			block_read(i, buf2);
			strcat(blockBuf, buf2);
			memcpy(&dataBlock, buf2, HALF_BLOCK);
		}
	}
	printf("444\n");
	for (int i = 1; i < 5; i++)
	{
		if (i == 1)
		{
			block_read(i, buf2);
			strcpy(blockBuf, buf2);
		}
		else if (i == 2)
		{
			block_read(i, buf2);
			strcat(blockBuf, buf2);
			memcpy(&nodeBlock, blockBuf, HALF_BLOCK);
		}
		else if (i == 3)
		{
			block_read(i, buf2);
			strcpy(blockBuf, blockBuf);
		}
		else if (i == 4)
		{
			block_read(i, buf2);
			strcat(blockBuf, buf2);
			memcpy(&dataBlock, blockBuf, HALF_BLOCK);
		}
	}
	printf("555\n");
	char dirBuf[DIR_SIZE];

	for (int i = 5; i < 22; i++)
	{
		if (i == 5)
		{
			block_read(i, buf2);
			strncpy(dirBuf, buf2,BLOCK_SIZE);
			continue;
		}

		block_read(i, buf2);
		strncat(dirBuf, buf2,BLOCK_SIZE);
	}

	memcpy(&rootDirList, dirBuf, DIR_SIZE);

	// superBlock.root = rootDirList;

	printf("666\n");

	// if (currectDirList)
	// fprintf(stderr, "index%d\n", superBlock.root->index);
	fprintf(stderr, "index2===%d\n", rootDirList.index);

	printf("777\n");
	close_disk(disk_name);
	fprintf(stderr, "%s\n", "Mounted Disk successful!");
	return 0;
}

int initSuperBlock(struct SuperBlock sb)
{
initlistD(5);
	sb.first_inode_index = 6192;
	sb.first_inode_idle_index = 6192;
	sb.first_inode_idle_index = 6192;
	sb.first_inode_block_index = 8192;
	sb.blockIndex = 8192;
	sb.iNodeNum = 256;
	sb.blockNum = 8192;
	sb.iNodeUsedNum = 0;
	sb.fileNum = 1;
	strcpy(sb.disk_name, diskName);
	sb.blockUsedNum = 0;
	// printf("------%s-----", sb.disk_name);
	char buf[BLOCK_SIZE];
	memcpy(buf, &sb, BLOCK_SIZE);
	int i = block_write(0, buf);
	// printf("dddddddddd%dddddddddd",sb.root->index);
	free(sb.root);


	


	if (i == 0)
	{
		fprintf(stderr, "initial successful\n");
		return 0;
	}

	return -1;
}

int initlistD(int i)
{
	struct Directory dir;
	dir.index = 5;
	dir.parent = 1;
	int j;
	char buf[DIR_SIZE];
	char temp[BLOCK_SIZE];
	memcpy(buf, &dir, DIR_SIZE);

	for (int k = 0; k < 17; k++)
	{
		strncpy(temp, buf + BLOCK_SIZE * k, BLOCK_SIZE);

		j = block_write(i + j, buf);

		if (j != 0)
		{
			fprintf(stderr, "Directory initial failed\n");
			return 1;
		}
	}

	fprintf(stderr, "rootindex2===%d===\n", dir.index);

	if (j == 0)
	{
		fprintf(stderr, "Root initial successful\n");
		return 1;
	}

	return 1;
}

/*  Function "runOneCommand"  :  used to Run a command */
int runOneCommand(char *command[])
{
	//check command
	int r;

	if (strcmp(command[0], "mkDisk") == 0)
	{

		r = make_disk(command[1]);
		if (r == 0)
		{
		}
		return 1;
	}
	else if (strcmp(command[0], "oDisk") == 0)
	{
		r = open_disk(command[1]);

		if (r == 0)
		{
			fprintf(stderr, "open disk successful \n");
			diskName = command[1];
		}

		return 2;
	}
	else if (strcmp(command[0], "cDisk") == 0)
	{
		r = close_disk(command[1]);

		if (r == 0)
		{
			diskName = NULL;
			fprintf(stderr, "close disk successful \n");
		}

		return 3;
	}
	else if (strcmp(command[0], "mkFS") == 0)
	{
		make_fs(command[1]);
		return 4;
	}
	else if (strcmp(command[0], "mouFS") == 0)
	{
		mount_fs(command[1]);

		return 5;
	}
	else if (strcmp(command[0], "echo") == 0)
	{
		return 6;
	}
	else if (strcmp(command[0], "help") == 0)
	{
		return 7;
	}
	else if (strcmp(command[0], "pause") == 0)
	{
		// return;
	}
	else if (strcmp(command[0], "quit") == 0)
	{
		return -1;
	}
	else
	{
		fprintf(stderr, "%s\n", "Can't find this command!! Retry!'");
		return 0;
	}
	return -1;
}

/*  Function "splitInput"  : split input for execute */
void splitInput(char *command[], char inputD[])
{

	char temp[1024][300];
	int i = 0; // the index of iputD
	int j = 0;
	int c = 0;	 // the index for temp
	int index = 0; // index for commands
	int bool1 = 1; //when input if not end
	int tick = 0;  // if not first 'space' or enter

	if (inputD[0] == '\0' || inputD[0] == 10)
	{

		return;
	}

	while (bool1)
	{
		while (inputD[i] == 10 || inputD[i] == ' ' || inputD[i] == '\t' || inputD[i] == '\0')
		{
			if (tick == 0)
			{
				i++;
				continue;
			}
			if (j == 0)
			{
				temp[index][c] = '\0';
				command[index] = temp[index];
				index += 1;
				c = 0;
				j++;
			}

			if (inputD[i] == '\0')
			{
				bool1 = 0;
				break;
			}
			i++;
		}

		temp[index][c] = inputD[i];

		tick = 1;
		c++;
		j = 0;
		i++;
	}

	command[index] = NULL;

} // end Function "splitInput"
