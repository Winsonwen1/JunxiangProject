	// 	copy(buf2, temp2, j,INODE_SIZE);
			// 	// strncat(buf2, temp2, BLOCK_SIZE);








		char buf2[DIR_SIZE];
		char temp2[BLOCK_SIZE];
		struct Directory dir2;
		for (int k = dir.index; k < dir.index+2; k++)
		{
			j = block_read(k, temp2);
			strncat(buf2, temp2, BLOCK_SIZE);
            	if (j != 0)
		{
			fprintf(stderr, "Directory initial failed\n");
			return -1;
		}
		}
		memcpy(&dir2, buf2, DIR_SIZE);
		// fprintf(stderr, "=======%d======\n", dir.index);
		// fprintf(stderr, "=======%d======\n", dir.parent);
		// fprintf(stderr, "=======%d======\n", dir2.index);
		// fprintf(stderr, "=======%d======\n", dir2.parent);


























int initlistD(int parentIndex)
{

	struct Directory dir;

	if (nodeBlock.used[600] == false)
	{
		dir.dirEntry = initEntry(DIRECTORY_ENTRY_BEGIN_INDEX);
	}
	else
	{
		// 当不是根目录
	}

	if (parentIndex == 0)
	{
		dir.index = DIRECTORY_BEGIN_INDEX;
	}
	else
	{
		// 当不是根目录
	}

	dir.parent = parentIndex;
	int j;
	char buf[DIR_SIZE];
	char temp[BLOCK_SIZE];
    // char temp3[BLOCK_SIZE];
	memcpy(buf, &dir, DIR_SIZE);
	for (int k = 0; k < 2; k++)
	{
		strncpy(temp, buf + (BLOCK_SIZE * k), BLOCK_SIZE);
		j = block_write(k+dir.index, temp);
		if (j != 0)
		{
			fprintf(stderr, "Directory initial failed\n");
			return -1;
		}
	}
	if (j == 0)
	{
		char buf2[DIR_SIZE];
		char temp2[BLOCK_SIZE];
		struct Directory dir2;
		for (int k = dir.index; k < dir.index+2; k++)
		{
			j = block_read(k, temp2);
			strncat(buf2, temp2, BLOCK_SIZE);
            	if (j != 0)
		{
			fprintf(stderr, "Directory initial failed\n");
			return -1;
		}
		}
		memcpy(&dir2, buf2, DIR_SIZE);
		// fprintf(stderr, "=======%d======\n", dir.index);
		// fprintf(stderr, "=======%d======\n", dir.parent);
		// fprintf(stderr, "=======%d======\n", dir2.index);
		// fprintf(stderr, "=======%d======\n", dir2.parent);

		return 0;
	}














































int initlistD(int parentIndex)
{

	struct Directory dir;

	if (nodeBlock.used[600] == false)
	{
		dir.dirEntry = initEntry(DIRECTORY_ENTRY_BEGIN_INDEX);
	}
	else
	{
		// 当不是根目录
	}

	if (parentIndex == 0)
	{
		dir.index = DIRECTORY_BEGIN_INDEX;
	}
	else
	{
		// 当不是根目录
	}

	dir.parent = parentIndex;
	int j;
	char buf[DIR_SIZE];
	char temp[BLOCK_SIZE];
    // char temp3[BLOCK_SIZE];
	memcpy(buf, &dir, DIR_SIZE);
    int x;
	for (int k = 0; k < 2; k++)
	{
        // if(k==0){
        //     strncpy(temp, buf + (BLOCK_SIZE * k), BLOCK_SIZE);
		//     j = block_write(5, temp);
        //     continue;
        // }

		strncpy(temp, buf + (BLOCK_SIZE * k), BLOCK_SIZE);
		j = block_write(k+dir.index, temp);
		if (j != 0)
		{
			fprintf(stderr, "Directory initial failed\n");
			return -1;
		}
	}


	// fprintf(stderr, "rootindex2===%d\n", dir->index);
	if (j == 0)
	{
		char buf2[DIR_SIZE];
		char temp2[BLOCK_SIZE];
        char temp4[BLOCK_SIZE];
		struct Directory dir2;
		for (int k = 5; k < 7; k++)
		{
            // if (k==5)
            // {
                // block_read(5, temp2);
                // strncpy(buf2, temp2, BLOCK_SIZE);
            //     continue;
            // }
            


			// if(k==5){
			block_read(k, temp2);
			strncat(buf2, temp2, BLOCK_SIZE);
			//     continue;
			// }
			// block_read(k, temp2);
			// strncpy(buf2, temp2, 769);
		}


        // strncpy(temp, buf + (BLOCK_SIZE * 0), BLOCK_SIZE);
        // block_write(5, temp);
	    // strncpy(temp3, buf + (BLOCK_SIZE * 1), BLOCK_SIZE);
    	//  block_write(6, temp3);
        
        // block_read(5, temp2);
        // strncpy(buf2, temp2, BLOCK_SIZE);
        // block_read(6, temp4);
	    // strncat(buf2, temp4, BLOCK_SIZE);
        // strncpy(buf2, temp, BLOCK_SIZE);
        // strncat(buf2, temp3, BLOCK_SIZE);


		memcpy(&dir2, buf2, DIR_SIZE);

		fprintf(stderr, "=======%d======\n", dir.index);
		fprintf(stderr, "=======%d======\n", dir.parent);
		fprintf(stderr, "=======%d======\n", dir2.index);
		fprintf(stderr, "=======%d======\n", dir2.parent);

		return 0;
	}

	return -1;
}