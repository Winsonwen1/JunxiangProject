#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

typedef struct INode
{
    int size; // number of block
    int blockNum[8192];
    int ctime;   //inode creating time
    char *owner; //owner of this file
    int otime;   //file open time
} iNode;
typedef struct Block
{
    int isUsed;
} block;
typedef struct DirectoryEntry
{
    int INode_id;                  // the id of file
    char *dirName;                 // the name of dir
    struct DirectoryEntry *next;   // the child of current directory
    struct DirectoryEntry *inDir2; // the directory in current directory
    struct DirectoryEntry *inDir;  // file in Same directory
} directory_entry;

typedef struct SuperBlock
{
    directory_entry *root;
    char *disk_name;
    int first_inode_index;
    int first_inode_idle_index;
    int first_inode_block_index;
    int blockIndex;
    int iNodeNum;
    int blockNum;
    int iNodeUsedNum;
    int blockUsedNum;

} super_block;

int main(int argc, char *argv[])
{
    int f, d;
    printf("=3");
    char buf[1024], buf2[1024];
    char buf3[1024], buf4[1024];

    printf("%d....", f);
    super_block *sb = (super_block *)malloc(sizeof(super_block));
    super_block *sb2 = (super_block *)malloc(sizeof(super_block));
    directory_entry *sb3 = (directory_entry *)malloc(sizeof(directory_entry));
    directory_entry *sb4 = (directory_entry *)malloc(sizeof(directory_entry));
    sb->blockNum = 111;
    sb3->INode_id = 222;
    sb->root = sb3;

    f = open("ni.txt", O_RDWR, 0644);
    memcpy(buf, &sb, sizeof(sb));

    write(f, buf, 1024);
    close(f);

    d = open("ni2.txt", O_RDWR, 0644);
    memcpy(buf3, &sb3, sizeof(sb3));
    write(d, buf3, 1024);
    close(d);
    free(sb);
    sb = NULL;

    printf("\n-------------%s--------------\n", buf3);
    printf("===========%d============\n", sb3->INode_id);

    f = open("ni.txt", O_RDWR, 0644);
    read(f, buf2, 1024);
    memcpy(&sb2, buf2, 1024);

    close(f);
    d = open("ni2.txt", O_RDWR, 0644);
    read(d, buf4, 1024);
    memcpy(&sb4, buf4, 1024);
    // printf("===========%d============\n", sb2->root->INode_id);
    close(d);
    sb2->root=sb4;
    // printf("\n-------------%s--------------\n", buf4);
    printf("===========%d============\n", sb2->root->INode_id);
    // printf("===========%d============\n", sb2->root->INode_id);
    printf("===========%d============\n", sb2->blockNum);
    printf("===========%d============\n", sb4->INode_id);
 printf("===========%d============\n", sb->blockNum);
    // printf("\n-------------%s--------------\n", buf2);
    // printf("===========%d====%d========\n", sizeof(sb), sizeof(struct INode));
    // printf("===========%d============\n", sb->blockNum);
    // printf("===========%d============", sb2->blockNum);
}