
#include "final4.h"
#include "disk.h"

// struct Directory dir;
int main()
{

	// unsigned char ss = 101;
	// char ss2 = 101;
	// printf("%c",ss);
	// printf("%c",ss2);
	// struct INode ii = {};
	for (int i = 0; i < 64; i++)
	{

		fd[i] = -1;
	}

	char inputD[MAX_BUFFER] = {}; // input data from user
	char *command[MAX_BUFFER] = {};
	isMout = 0;
	isOpen = 0;
	// int r; //store return value

	while (1)
	{
		fprintf(stderr, "%s", "Please type your command: ");

		fgets(inputD, sizeof(char) * MAX_BUFFER, stdin);
		splitInput(command, inputD);

		runOneCommand(command);
	}
}

int runOneCommand(char *command[])
{
	//check command
	int r;
	if (command[0] == NULL)
	{
		fprintf(stderr, "%s\n", "Can't find this command!! Retry!'");
		return 0;
	}
	if (strcmp(command[0], "mkDisk") == 0)
	{

		r = make_disk(command[1]);
		if (r == 0)
		{
		}
		return 1;
	}
	else if (strcmp(command[0], "oDisk") == 0)
	{
		r = open_disk(command[1]);

		if (r == 0)
		{
			isOpen = 1;
			fprintf(stderr, "open disk successful \n");
			diskName = command[1];
		}

		return 2;
	}
	else if (strcmp(command[0], "cDisk") == 0)
	{
		r = close_disk(command[1]);

		if (r == 0)
		{
			isOpen = 0;
			diskName = NULL;
			fprintf(stderr, "close disk successful \n");
		}

		return 3;
	}
	else if (strcmp(command[0], "mkFS") == 0)
	{
		make_fs(command[1]);
		return 4;
	}
	else if (strcmp(command[0], "mouFS") == 0)
	{
		mount_fs(command[1]);

		return 5;
	}
	else if (strcmp(command[0], "umouFS") == 0)
	{
		umount_fs(command[1]);
		return 6;
	}
	else if (strcmp(command[0], "mkFile") == 0)
	{
		fs_create(command[1]);
		return 7;
	}
	else if (strcmp(command[0], "mkDir") == 0)
	{
		fs_mkdir(command[1]);
		return 8;
	}
	else if (strcmp(command[0], "ls") == 0)
	{
		call_ls();
		return 8;
	}
	else if (strcmp(command[0], "opFile") == 0)
	{
		fs_open(command[1]);
		return 9;
	}
	else if (strcmp(command[0], "cFile") == 0)
	{
		if (isdigit(command[1][0]) != 0)
		{
			fprintf(stderr, "%s\n", "Ple enter an interger.");
			return -1;
		}
		int num = atoi(command[1]);
		fs_close(num);
		return 9;
	}
	else if (strcmp(command[0], "getSize") == 0)
	{
		if (isdigit(command[1][0]) != 0)
		{
			fprintf(stderr, "%s\n", "Ple enter an interger.");
			return -1;
		}
		int num = atoi(command[1]);
		fs_get_filesize(num);
		return 9;
	}
	else if (strcmp(command[0], "readFile") == 0)
	{
		if (isdigit(command[1][0]) != 0 || isdigit(command[2][0]) != 0)
		{
			fprintf(stderr, "%s\n", "Ple enter an interger.");
			return -1;
		}
		int num = atoi(command[1]);
		int num2 = atoi(command[2]);
		if (num < 0 || num >= 64 || num2 <= 0)
		{
			fprintf(stderr, "%s\n", "Invaile number");
			return -1;
		}
		fs_read(num, rwBuf, num2);

		return 9;
	}
	else if (strcmp(command[0], "quit") == 0)
	{
		umount_fs(diskName);
		fprintf(stderr, "%s\n", "See you soon!!!");
		exit(1);
		return -1;
	}
	else
	{
		fprintf(stderr, "%s\n", "Can't find this command!! Retry!");
		return 0;
	}
	return -1;
}

int fs_read(int fildes, void *buf, size_t nbyte)
{
	if (isMout == 0)
	{
		fprintf(stderr, "%s\n", "Please mount a disk first.");
		return -1;
	}
	// if (fildes < 0 || fildes >= 64)
	// {
	// 	fprintf(stderr, "%s\n", "Invaile number");
	// 	return -1;
	// }

	if (fd[fildes] == -1)
	{
		fprintf(stderr, "%s\n", "File is not opened yet. Try it again.");
		return -1;
	}

	struct INode inodeTemp;
	inodeTemp = inode[fildes];

	if (inodeTemp.size == 0)
	{
		fprintf(stderr, "%s\n", "No data in such file. Try it again.");
		return -1;
	}

	int k = 0;
	//read from offset into the end
	for (; inodeTemp.blockNum[k] != 0; k++)
	{
		copyFile(buf, inodeTemp.blockNum[k], k, inodeTemp.size);
	}

	// int startBlock = (inodeTemp.offset + 1) / BLOCK_SIZE;

	if (inodeTemp.offset + nbyte >= inodeTemp.size)
	{
		for(int i = inodeTemp.offset; i<inodeTemp.size;i++){
			char
		}
	}
	else
	{
	}

	return 0;
}












int fs_get_filesize(int fildes)
{
	if (isMout == 0)
	{
		fprintf(stderr, "%s\n", "Please mount a disk first.");
		return -1;
	}
	if (fildes < 0 || fildes >= 64)
	{
		fprintf(stderr, "%s\n", "Invaile number");
		return -1;
	}

	if (fd[fildes] == -1)
	{
		fprintf(stderr, "%s\n", "File is not opened yet. Try it again.");
		return -1;
	}

	printf("The size of this file is %d.", inode[fildes].size);
	return inode[fildes].size;
}

int fs_close(int fildes)
{

	if (isMout == 0)
	{
		fprintf(stderr, "%s\n", "Please mount a disk first.");
		return -1;
	}
	if (fildes < 0 || fildes >= 64)
	{
		fprintf(stderr, "%s\n", "Invaile number");
		return -1;
	}

	if (fd[fildes] == -1)
	{
		fprintf(stderr, "%s\n", "File is not opened yet. Try it again.");
		return -1;
	}

	superBlock.fileOpen--;
	memset(&inode[fildes], 0, INODE_SIZE);
	fd[fildes] = -1;
	fprintf(stderr, "%s\n", "File closed successful.");
	return 0;
}

int fs_open(char *name)
{
	if (!name)
	{
		fprintf(stderr, "%s\n", "Invaile name");
		return -1;
	}
	if (isMout == 0)
	{
		fprintf(stderr, "%s\n", "Please mount a disk first.");
		return -1;
	}
	if (strlen(name) > MAX_DIR_CHAR)
	{
		fprintf(stderr, "%s\n", "the name is too long (it exceeds 15 characters), Request Reject!");
		return -1;
	}
	if (superBlock.fileOpen >= 64)
	{
		fprintf(stderr, "%s\n", "The maximum of file descriptors(64) is used, Request Reject!");
		return -1;
	}

	int inodeIndex;
	int fdIndex;
	for (int i = 0; i < MAX_FILES; i++)
	{
		if (strcmp(currectEntry.fileName[i], name) == 0)
		{
			inodeIndex = currectEntry.INode_id[i];
			break;
		}
		else if (i == MAX_FILES - 1)
		{
			fprintf(stderr, "%s\n", "No such file in current directory, Request Reject!");
			return -1;
		}
	}

	for (int i = 0; i <= 64; i++)
	{
		if (fd[i] == -1)
		{
			fdIndex = i;
			fd[i] = inodeIndex;
			break;
		}
	}
	superBlock.fileOpen++;

	// inode[fdIndex];
	char temp2[BLOCK_SIZE];
	char buf2[INODE_SIZE] = {};
	for (int k = 0; k < 5; k++)
	{
		block_read(k + inodeIndex, temp2);
		copy(buf2, temp2, k - 1, DOUBLE_BLOCK_SIZE);
		// block_read(k, temp2);
		// 	strncat(buf2, temp2, BLOCK_SIZE);
	}
	memcpy(&inode[fdIndex], buf2, INODE_SIZE);

	inode[fdIndex].offset = 0;
	fprintf(stderr, "%s\n", "File open successful!");
	fprintf(stderr, "%s%d\n", "File descriptor is ", fdIndex);
	return fdIndex;
}

int call_ls()
{
	if (isMout == 0)
	{
		fprintf(stderr, "%s\n", "Please mount a disk first.");
		return -1;
	}

	fprintf(stderr, "%s\n", "Directory in current directory:");
	for (int i = 0; i < MAX_FILES; i++)
	{
		if (strlen(currectDirList.dirName[i]) != 0)
		{
			printf("%s\n", currectDirList.dirName[i]);
		}
	}
	fprintf(stderr, "\n%s\n", "Directory in current directory:");
	for (int i = 0; i < MAX_FILES; i++)
	{
		if (strlen(currectEntry.fileName[i]) != 0)
		{
			printf("%s\n", currectEntry.fileName[i]);
		}
	}
	return 0;
}

int fs_mkdir(char *name)
{
	//The maximum length for a file name is 15 characters
	//at most 256 files in the directory
	//The max number of block is 8192
	if (!name)
	{
		fprintf(stderr, "%s\n", "Invaile name");
		return -1;
	}
	if (isMout == 0)
	{
		fprintf(stderr, "%s\n", "Please mount a disk first.");
		return -1;
	}
	if (strlen(name) > MAX_DIR_CHAR)
	{
		fprintf(stderr, "%s\n", "the directory name is too long (it exceeds 15 characters), Request Reject!");
		return -1;
	}
	if (superBlock.fileNum >= MAX_FILES)
	{
		fprintf(stderr, "%s\n", "Over 256 files in the directory, Request Reject!");
		return -1;
	}
	if (superBlock.blockUsedNum >= HALF_BLOCK)
	{
		fprintf(stderr, "%s\n", "Over the max number of block(8192), Request Reject!");
		return -1;
	}
	if (superBlock.iNodeUsedNum >= MAX_INODE)
	{
		fprintf(stderr, "%s\n", "Over the max number of INode(256), Request Reject!");
		return -1;
	}

	for (int i = 0; i < MAX_FILES; i++)
	{
		if (strcmp(currectDirList.dirName[i], name) == 0)
		{
			fprintf(stderr, "%s\n", "There are same name of directory in currect directory, Request Reject!");
			return -1;
		}
	}
	// printf("---------%s-----------\n",currectEntry.dirName[0]);
	// printf("lllllll   %d   llllllllll\n",strcmp(currectEntry.dirName[0], name));
	// 	printf("lllllll   %d   llllllllll\n",strcmp(currectEntry.dirName[0], ""));
	// printf("=========%s=======\n",name);
	for (int i = 0; i < MAX_FILES; i++)
	{
		if (strcmp(currectDirList.dirName[i], "") == 0)
		{
			int j = initlistD(currectDirList.index);
			if (j == -1)
			{
				fprintf(stderr, "%s\n", "Can't create file!");
				return -1;
			}

			strcpy(currectDirList.dirName[i], name);
			currectDirList.childList[i] = i;
			fprintf(stderr, "%s\n", "Directory created successful!");

			// fprintf(stderr, "%d\n", currectDirList.childList[i]);
			// fprintf(stderr, "%s\n", currectDirList.dirName[i]);
			// fprintf(stderr, "%d\n", currectDirList.parent);

			// fprintf(stderr, "%d\n", currectDirList.dirEntry);

			return 0;
		}
	}
	fprintf(stderr, "%s\n", "Can't create file!");
	return -1;
}

int fs_create(char *name)
{
	//The maximum length for a file name is 15 characters
	//at most 256 files in the directory
	//The max number of block is 8192
	if (!name)
	{
		fprintf(stderr, "%s\n", "Invaile name");
		return -1;
	}
	if (isMout == 0)
	{
		fprintf(stderr, "%s\n", "Please mount a disk first.");
		return -1;
	}
	if (strlen(name) > MAX_DIR_CHAR)
	{
		fprintf(stderr, "%s\n", "the file name is too long (it exceeds 15 characters), Request Reject!");
		return -1;
	}
	if (superBlock.fileNum >= MAX_FILES)
	{
		fprintf(stderr, "%s\n", "Over 256 files in the directory, Request Reject!");
		return -1;
	}
	if (superBlock.blockUsedNum >= HALF_BLOCK)
	{
		fprintf(stderr, "%s\n", "Over the max number of block(8192), Request Reject!");
		return -1;
	}
	if (superBlock.iNodeUsedNum >= MAX_INODE)
	{
		fprintf(stderr, "%s\n", "Over the max number of INode(256), Request Reject!");
		return -1;
	}

	for (int i = 0; i < MAX_FILES; i++)
	{
		if (strcmp(currectEntry.fileName[i], name) == 0)
		{
			fprintf(stderr, "%s\n", "There are same name of file in currect directory, Request Reject!");
			return -1;
		}
	}
	// printf("---------%s-----------\n",currectEntry.dirName[0]);
	// printf("lllllll   %d   llllllllll\n",strcmp(currectEntry.dirName[0], name));
	// 	printf("lllllll   %d   llllllllll\n",strcmp(currectEntry.dirName[0], ""));
	// printf("=========%s=======\n",name);
	for (int i = 0; i < MAX_FILES; i++)
	{
		if (strcmp(currectEntry.fileName[i], "") == 0)
		{
			int j = initINode();
			if (j == -1)
			{
				fprintf(stderr, "%s\n", "Can't create file!");
				return -1;
			}

			strcpy(currectEntry.fileName[i], name);
			currectEntry.INode_id[i] = j;
			fprintf(stderr, "%s\n", "File created successful!");
			fprintf(stderr, "currectEntry:%d\n", currectEntry.index);
			return 0;
		}
	}
	fprintf(stderr, "%s\n", "Can't create file!");
	return -1;
}

int umount_fs(char *disk_name)
{
	//o write back all meta-information so that the disk persistently reflects
	//all changes that were made to the file system
	//close the disk. The function returns 0 on success, and -1 when the
	//disk disk_name could not be closed or when data could not be written to the disk

	if (isMout != 1)
	{
		fprintf(stderr, "File system is not mounted yet!! \n");
		return -1;
	}

	if (strcmp(disk_name, diskName) != 0)
	{
		fprintf(stderr, "File system is not mounted yet!! \n");
		return -1;
	}
	if (closeFD() == 0)
	{

		if (wirteBacklistD(DIRECTORY_BEGIN_INDEX) == 0)
		{
			if (wirteBackBlock() == 0)
			{

				if (wirteBackSuperBlock() == 0)
				{
					if (wirteDirEntry() == 0)
					{
						if (close_disk(disk_name) == 0)
						{

							isOpen = 0;
							strcpy(pwd, "");
							diskName = NULL;
							isMout = 0;
							fprintf(stderr, "umounted file system successful\n");
							return 0;
						}

						return -1;
					}
					fprintf(stderr, "Storing Dir Entry failed\n");
					return -1;
				}
				fprintf(stderr, "Storing super block failed\n");
				return -1;
			}
			fprintf(stderr, "Storing nodeBlockk or dataBlock failed\n");
			return -1;
		}
		fprintf(stderr, "Store dir failed\n");
		return -1;
	}
	close_disk(disk_name);
	isOpen = 0;
	fprintf(stderr, "Close files failed\n");
	return -1;
}

int closeFD()
{
	for (int i = 0; i < 64; i++)
	{
		if (fd[i] != -1)
		{

			if (fs_close(i) == -1)
			{
				return -1;
			}
		}
		// fprintf(stderr, "%d\n",i);
	}
	return 0;
}

int mount_fs(char *disk_name)
{
	//open the disk and then load the meta-information
	// that is necessary to handle the file system operations
	// The function returns 0 on success, and -1 when the disk disk_name could not
	//be opened or when the disk does not contain a valid file system
	char buf2[BLOCK_SIZE];
	char blockBuf[DOUBLE_BLOCK_SIZE];

	if (open_disk(disk_name) == -1)
	{

		return -1;
	}
	isOpen = 1;
	//initial super block
	block_read(0, buf2);
	memcpy(&superBlock, buf2, SUPER_BLOCK_SIZE);
	printf("==========%d\n", 444);
	if (superBlock.blockNum == 0)
	{
		fprintf(stderr, "%s\n", "File System is not initail yet, Ple make a File System for this disk first ");
		close_disk(disk_name);
		isOpen = 0;
		return -1;
	}

	printf("==========%d\n", 333);
	// initial nodeBlock and data Block
	for (int i = 1; i < 5; i++)
	{
		if (i == 1)
		{
			block_read(i, buf2);
			// strncpy(blockBuf, buf2, BLOCK_SIZE);
			copy(blockBuf, buf2, i - 1, DOUBLE_BLOCK_SIZE);
			// 	// strncat(buf2, temp2, BLOCK_SIZE);
		}
		else if (i == 2)
		{
			block_read(i, buf2);
			copy(blockBuf, buf2, i - 1, DOUBLE_BLOCK_SIZE);
			// strncat(blockBuf, buf2, BLOCK_SIZE);
			memcpy(&nodeBlock, blockBuf, DOUBLE_BLOCK_SIZE);
		}
		else if (i == 3)
		{
			block_read(i, buf2);
			copy(blockBuf, buf2, i - 3, DOUBLE_BLOCK_SIZE);
			// strncpy(blockBuf, buf2, BLOCK_SIZE);
		}
		else if (i == 4)
		{
			block_read(i, buf2);
			copy(blockBuf, buf2, i - 3, DOUBLE_BLOCK_SIZE);
			// strncat(blockBuf, buf2, BLOCK_SIZE);
			memcpy(&dataBlock, blockBuf, DOUBLE_BLOCK_SIZE);
		}
	}
	//initial rootDirlist
	char dirBuf[DIR_SIZE];

	for (int k = 5; k < 7; k++)
	{
		if (k == 5)
		{
			block_read(k, buf2);
			copy(dirBuf, buf2, k - 5, DIR_SIZE);
			// strncpy(dirBuf, buf2, BLOCK_SIZE);
			continue;
		}
		// if(k==21){
		// 	block_read(k, buf2);
		// 	strncat(dirBuf, buf2, 3828);
		// 	break;
		// }

		block_read(k, buf2);
		copy(dirBuf, buf2, k - 5, DIR_SIZE);
		// strncat(dirBuf, buf2, BLOCK_SIZE);
	}

	memcpy(&currectDirList, dirBuf, DIR_SIZE);
	// printf("==========%d\n", currectDirList.index);

	// update pwd
	// strcpy(pwd, diskName);
	for (int j = 0; disk_name[j] != '\0'; j++)
	{

		pwd[j] = disk_name[j];
	}
	strcat(pwd, ":/root/");

	char entryBuf[ENTRY_SIZE];

	for (int k = 600; k < 602; k++)
	{
		if (k == 600)
		{
			block_read(k, buf2);
			copy(entryBuf, buf2, k - 600, ENTRY_SIZE);
			// strncpy(dirBuf, buf2, BLOCK_SIZE);
			continue;
		}
		// if(k==21){
		// 	block_read(k, buf2);
		// 	strncat(dirBuf, buf2, 3828);
		// 	break;
		// }

		block_read(k, buf2);
		copy(entryBuf, buf2, k - 600, DIR_SIZE);
		// strncat(dirBuf, buf2, BLOCK_SIZE);
	}

	memcpy(&currectEntry, entryBuf, DIR_SIZE);

	// fprintf(stderr, "----%d----\n", superBlock.blockNum);
	// fprintf(stderr, "----%d----\n", nodeBlock.used[1]);
	// fprintf(stderr, "----%d----\n", currectEntry.index);
	fprintf(stderr, "%s\n", "Mounted Disk successful!");
	isMout = 1;

	diskName = disk_name;
	return 0;
}

int make_fs(char *disk_name)
{
	// first invoke make_disk(disk_name) to create a new disk
	//  open this disk and write/initialize the necessary meta-information
	// for file system
	// The function returns 0 on success, and -1 when the disk
	// disk_name could not be created, opened, or properly initialized.

	char inputD[1024] = {};
	char buf2[BLOCK_SIZE];
	struct SuperBlock sb2 = {};

	if (isOpen == 1)
	{
		fprintf(stderr, "%s\n", "Please closed disk first ");
		return -1;
	}
	if (open_disk(disk_name) == -1)
	{
		if (make_disk(disk_name) == -1)
		{

			return -1;
		}
		if (open_disk(disk_name) == -1)
		{
			return -1;
		}
	}

	block_read(0, buf2);
	memcpy(&sb2, buf2, BLOCK_SIZE);
	close_disk(disk_name);
	isOpen = 0;
	// printf("-----------%d--------", sb2.blockNum);

	if (sb2.blockNum != 0)
	{
		fprintf(stderr, "%s\n", "File System is initail already, Type '1' if u wanna continue ");
		fgets(inputD, sizeof(char) * MAX_BUFFER, stdin);
		if (inputD[0] != '1')
		{
			fprintf(stderr, "%s\n", "Back to the main menu ");
			return 0;
		}
	}

	if (make_disk(disk_name) == 0)
	{
		if (open_disk(disk_name) == 0)
		{
			isOpen = 1;
			diskName = disk_name;
			if (initlistD(0) == 0)
			{
				if (initBlock() == 0)
				{
					if (initSuperBlock(sb2) == 0)
					{
						if (close_disk(disk_name) == 0)
						{
							isOpen = 0;
							diskName = NULL;
							return 0;
						}

						return -1;
					}
					fprintf(stderr, "initial super block failed\n");
					return -1;
				}
				fprintf(stderr, "initial nodeBlockk or dataBlock failed\n");
				return -1;
			}
			fprintf(stderr, "initial rootDirList failed\n");
			return -1;
		}
		fprintf(stderr, "initial superblock failed\n");
	}

	return -1;
}

/*  Function "runOneCommand"  :  used to Run a command */

/*  Function "splitInput"  : split input for execute */
void splitInput(char *command[], char inputD[])
{

	char temp[1024][300];
	int i = 0; // the index of iputD
	int j = 0;
	int c = 0;	 // the index for temp
	int index = 0; // index for commands
	int bool1 = 1; //when input if not end
	int tick = 0;  // if not first 'space' or enter

	if (inputD[0] == '\0' || inputD[0] == 10)
	{

		return;
	}

	while (bool1)
	{
		while (inputD[i] == 10 || inputD[i] == ' ' || inputD[i] == '\t' || inputD[i] == '\0')
		{
			if (tick == 0)
			{
				i++;
				continue;
			}
			if (j == 0)
			{
				temp[index][c] = '\0';
				command[index] = temp[index];
				index += 1;
				c = 0;
				j++;
			}

			if (inputD[i] == '\0')
			{
				bool1 = 0;
				break;
			}
			i++;
		}

		temp[index][c] = inputD[i];

		tick = 1;
		c++;
		j = 0;
		i++;
	}

	command[index] = NULL;

} // end Function "splitInput"

char *writeCopy(char *des, char *src, int index, int size)
{
	int i = index * BLOCK_SIZE;
	int end = (index + 1) * BLOCK_SIZE;
	if (end > size)
	{
		end = size;
	}
	int j = 0;

	for (; i < end; i++, j++)
	{
		des[j] = src[i];
		// printf("%c",des[j] );
	}
	printf("\n%s====1=====%d\n", des, end);
	return des;
}

char *copy(char *des, char *src, int index, int size)
{
	int i = index * BLOCK_SIZE;
	int end = (index + 1) * BLOCK_SIZE;
	if (end > size)
	{
		end = size;
	}
	int j = 0;

	for (; i < end; i++, j++)
	{
		des[i] = src[j];
		// printf("%c",src[j] );
	}
	printf("\n%s====2=====%d\n", src, end);
	return des;
}

char *copyFile(char *des, short blockIndex, int index, int size)
{
	char buf[BLOCK_SIZE];
	block_read(blockIndex, buf);
	int i = index * BLOCK_SIZE;
	int end = (index + 1) * BLOCK_SIZE;
	if (end > size)
	{
		end = size;
	}
	int j = 0;

	for (; i < end; i++, j++)
	{
		des[i] = buf[j];
		// printf("%c",src[j] );
	}

	des[i] = EOF;

	return des;
}
